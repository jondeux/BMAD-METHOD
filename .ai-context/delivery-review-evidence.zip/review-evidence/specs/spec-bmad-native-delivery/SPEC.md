---
id: SPEC-bmad-native-delivery
companions: [implementation.md]
sources: []
---

# Native workflow execution for BMad delivery

## Why

The prototype can generate and verify artifacts through its Codex worker. Invoke native BMad workflows so the run can prove which workflow actually executed.

## Capabilities

- **CAP-1**
  - **intent:** The delivery command can dispatch native Build Auto for code and the native product brief workflow for documents.
  - **success:** A mixed request produces workflow-specific receipts, native working artifacts, and final deliverables. A named workflow produces evidence of an invocation before any claim of completion.
- **CAP-2**
  - **intent:** A user can authorize, interrupt, and resume one live mixed delivery with its original authority and acceptance checks intact.
  - **success:** Mode A pauses before dispatch, a killed controller resumes from the completed native receipt, and independent acceptance verifies both outputs within the call cap.

## Constraints

- Preserve A/B/C authority, the original check IDs and meanings, and the hard worker-call cap.
- Isolate workflow writes within each run. Use a version-matched renderer and Build Auto templates. Retain results and failures for replay and audit.
- Use the host's supported tools and sandbox. External publication and worktree integration require separate authorization.

## Non-goals

- Production deployment or automatic integration of the generated work.
- Adding adapters for every ecosystem workflow in this milestone.

## Success signal

One live Mode A mixed run yields a working SQLite query and a source-faithful decision brief. Its record shows both native invocations, approval timing, restored progress, acceptance outcomes, and artifact hashes.

## Assumptions

- A synthetic room booking project and a simulated fixture owner are suitable for the mixed-run demonstration.
