# Live autonomous delivery verification

The signed-in Codex CLI used GPT-5.6 Luna at medium effort and delivered both synthetic requests. The final file hashes matched the run records and the original build receipts.

| Run | Result | Evidence |
| --- | --- | --- |
| Mode B decision brief | Three live calls selected the deliverable, drafted the brief and confirmed the source limitation and decision ownership. | [Brief](document/artifacts/decision-brief.txt) · [Run record](document/state.json) |
| Mode C SQLite query | Two live calls selected the route and generated the query. An independent SQLite checker tested overlap, both interval boundaries, another room and an empty table. All four checks passed after checker repair. | [Query](code-with-worker-contract/artifacts/availability.sql) · [Run record](code-with-worker-contract/state.json) |

The first code routing attempt asked for execution tools even though a separate checker owned verification. The worker now receives that execution boundary in its job. The next code run generated the query, but the checker denied its own setup transaction commit. The corrected checker committed its seed data before enabling read-only authorization. The controller used `--reverify --budget 4` to rerun the check on the original SQL. The failed and passing receipts remain in the run record.

Native Build and Build Auto both rendered with the checkout's renderer and templates from the same revision. The live runs exercised the delivery controller and its workers. Native rendering was checked separately.
