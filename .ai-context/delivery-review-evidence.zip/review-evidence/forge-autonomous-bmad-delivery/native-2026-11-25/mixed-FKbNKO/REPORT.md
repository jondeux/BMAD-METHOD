# Native mixed delivery verification

The feature branch baseline is `c8464fa6`. The synthetic Mode A run completed with four controller dispatches against a cap of four. It produced two local artifacts and passed six original checks.

| Evidence | Observed result |
| --- | --- |
| [Pre-approval state](pre-approval.json) | Routing proposed the mixed deliverable. Zero native workflows had started. The fixture owner approved proposal 1. |
| [Build Auto plan](run/attempts/2/workspace/_bmad-output/plan-room-availability-sql.md) | The matched renderer loaded the native oneshot workflow. Build Auto implemented the query, ran its five executable cases, completed its quick review and reported `built`. |
| [Interruption](recovery-event.json) | The controller was suspended while the native code receipt was written and synchronized, then killed. A different process adopted the same hashed receipt and dispatched Product Brief. |
| [Product Brief result](run/attempts/3/workspace/native-brief-result.json) | The native headless workflow wrote the brief and memory log. Both editorial passes ran and all four recommendations were applied. |
| [Final status](final-status.json) | All six checks passed, and every native evidence and published artifact hash matched the saved record. |

Published artifacts are [availability.sql](run/artifacts/availability.sql) and [brief.md](run/artifacts/brief.md). The independent verifier executed the query against an in-memory SQLite case set with a read-only statement authorizer and checked the brief against the source note.

The standalone Codex CLI received a kernel denial when launching its shell sandbox. The authorized workspace agent served the native jobs. Product Brief used the unchanged native memory script with the workspace's Python and PyYAML 6.0.1 when offline uv could not obtain its declared dependency. The live run used a simulated approver for this fixture. The call cap counts controller dispatches.

Regression verification passed 1,259 tests and 198 subtests. Strict skill validation found zero issues across 33 directories.
