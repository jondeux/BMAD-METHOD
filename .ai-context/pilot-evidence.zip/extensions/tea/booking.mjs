export function createBookings() {
  const owners = new Map();
  return {
    hold(room, visitDate, requester) {
      const slot = JSON.stringify([room, visitDate]);
      if (owners.has(slot) && owners.get(slot) !== requester) return "conflict";
      owners.set(slot, requester);
      return "held";
    },
  };
}
