import assert from "node:assert/strict";
import { test } from "node:test";
import { createBookings } from "../booking.mjs";

const date = "2026-12-04";

test("AC-1 first hold succeeds", () => {
  assert.equal(createBookings().hold("North Gallery", date, "Mira"), "held");
});

test("AC-2 duplicate request from a different person conflicts", () => {
  const bookings = createBookings();
  bookings.hold("North Gallery", date, "Mira");
  assert.equal(bookings.hold("North Gallery", date, "Sol"), "conflict");
  assert.equal(bookings.hold("North Gallery", date, "Mira"), "held");
});

test("AC-3 retry preserves the original hold", () => {
  const bookings = createBookings();
  bookings.hold("North Gallery", date, "Mira");
  assert.equal(bookings.hold("North Gallery", date, "Mira"), "held");
});

test("AC-4 same date in another room stays available", () => {
  const bookings = createBookings();
  bookings.hold("North Gallery", date, "Mira");
  assert.equal(bookings.hold("Cedar Room", date, "Sol"), "held");
});
