import subprocess
import sys
import unittest
from pathlib import Path


class DurationCli(unittest.TestCase):
    def invoke(self, *args):
        result = subprocess.run(
            [sys.executable, str(Path(__file__).with_name("duration.py")), *args],
            capture_output=True,
            text=True,
            check=False,
        )
        return result.returncode, result.stdout, result.stderr

    def test_default(self):
        self.assertEqual(self.invoke(), (0, "30\n", ""))

    def test_override(self):
        self.assertEqual(self.invoke("15"), (0, "15\n", ""))

    def test_invalid(self):
        for args in [("30",), ("",), ("15", "15"), ("-h",)]:
            with self.subTest(args=args):
                self.assertEqual(self.invoke(*args), (2, "", "usage: duration.py [15]\n"))
