import sys


def main(args):
    if not args:
        print(30)
        return 0
    if args == ["15"]:
        print(15)
        return 0
    print("usage: duration.py [15]", file=sys.stderr)
    return 2


if __name__ == "__main__":
    raise SystemExit(main(sys.argv[1:]))
