# Fictional studio pilot source packet

All people, sites, studies, bookings and prototype details in this packet are invented for the test.

## IDEA — raw idea

Forty staff need room availability, booking and cancellation, concurrent overlap prevention, mobile and desktop access, and administrative corrections. Pilot is two weeks in one building with three rooms. No payments or calendar integration. Recurrence and check-in are optional. Back-to-back bookings should work. A delayed check-in must never cancel the later booking.

## LIT — literature dump

- FIX-STUDY-01. In a fictional 12-person test, 8 missed a hidden cancellation control. Investigate a visible control.
- FIX-STUDY-02. In a fictional 9-booking simulation, 3 unused rooms were released at 10 minutes versus 2 at 15 minutes. False releases were unmeasured. No threshold conclusion.
- FIX-STUDY-03. In a fictional 6-person walkthrough, 4 expected adjacent slots to work. Treat this as a hypothesis.

## BRAIN — brainstorming

Availability grid, one-tap check-in and a countdown were brainstormed. Consider accessibility, accidental release and concurrency. Staff prefer low-friction booking. Facilities wants to reclaim unused rooms. The 10- versus 15-minute no-check-in release threshold is disputed.

## FORGE — Forge session handoff and brownfield description

Challenge the burden of check-in. Establish an owner for the 10/15-minute decision. Prevent concurrent double booking. The tiny existing Flask prototype is described as holding in-memory booking dictionaries with `GET /rooms` and `POST /bookings`, accepting start/end strings with no timezone validation, using inclusive conflict endpoints, and losing data on restart. Actual source was not provided.

## STAKEHOLDER — paths and updates

- C1 names a director decision brief with evidence versus assumptions, unresolved policy, decision owner, options, and next steps.
- C2 names a working standalone prototype demonstrating availability, bookings, cancellation, conflict prevention, adjacency and safe check-in timing, with run and verification instructions. The interactive spreadsheet suggestion came without approval to replace C2.
- B delegates deliverable choice for an evidence-based, no-cost decision before the next meeting. Facilities then reported the pilot building was unavailable for the first week. The revised meeting question compares postponing and using an existing alternative building.
- A explicitly confirms brownfield discovery, bounded Build, and an operator guide; keep existing GET and POST routes, defer persistence and automatic release. The owner confirmed check-in in `[start, end)` only, otherwise HTTP 409 with neither booking changed. The owner declined the suggested persistence migration as a replacement.
