import json
import subprocess
import sys
import unittest
from pathlib import Path

HERE = Path(__file__).parent


def run_cli(source):
    output = subprocess.run([sys.executable, str(HERE / "rooms.py")], input=source,
                            text=True, capture_output=True, check=True)
    return [json.loads(line) for line in output.stdout.splitlines()]


class PrototypeCli(unittest.TestCase):
    def test_full_demo(self):
        result = run_cli((HERE / "demo.jsonl").read_text())
        self.assertEqual(result, [
            {"available": ["Maple", "Cedar", "Birch"]}, {"id": 1},
            {"error": "booking overlaps"}, {"id": 2},
            {"error": "check-in outside booking interval"}, {"id": 1, "checked_in": False},
            {"id": 2, "checked_in": False},
            {"id": 2, "checked_in": True}, {"available": ["Cedar", "Birch"]},
            {"cancelled": 2}, {"available": ["Maple", "Cedar", "Birch"]},
        ])

    def test_invalid_inputs_do_not_consume_ids(self):
        commands = [
            {"action": "book", "room": "Maple", "start": "2026-11-24T10:00", "end": "2026-11-24T11:00+00:00"},
            {"action": "book", "room": "Maple", "start": "2026-11-24T10:00+00:00", "end": "2026-11-24T11:00+02:00"},
            {"action": "book", "room": "Maple", "start": "2026-11-24T10:00Z", "end": "2026-11-24T11:00+00:00"},
            {"action": "cancel", "id": True},
            {"action": "status", "id": 1},
        ]
        result = run_cli("\n".join(map(json.dumps, commands)))
        self.assertIn("UTC offset", result[0]["error"])
        self.assertEqual(result[1:], [{"error": "end must follow start"}, {"id": 1},
                                      {"error": "unknown booking"}, {"id": 1, "checked_in": False}])
