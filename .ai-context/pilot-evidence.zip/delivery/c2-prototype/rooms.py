import json
import sys
from datetime import datetime, timezone
from itertools import count

ROOMS = ("Maple", "Cedar", "Birch")


def timestamp(value):
    if not isinstance(value, str):
        raise ValueError("use an ISO 8601 timestamp with a UTC offset")
    parsed = datetime.fromisoformat(value)
    if parsed.utcoffset() is None:
        raise ValueError("use an ISO 8601 timestamp with a UTC offset")
    return parsed.astimezone(timezone.utc)


class Studio:
    def __init__(self):
        self.bookings = {}
        self.ids = count(1)

    def apply(self, event):
        action = event["action"]
        if action in {"available", "book"}:
            start, end = timestamp(event["start"]), timestamp(event["end"])
            if start >= end:
                raise ValueError("end must follow start")
            occupied = {
                booking["room"] for booking in self.bookings.values()
                if booking["start"] < end and start < booking["end"]
            }
            if action == "available":
                return {"available": [room for room in ROOMS if room not in occupied]}
            room = event["room"]
            if room not in ROOMS:
                raise ValueError("unknown room")
            if room in occupied:
                raise ValueError("booking overlaps")
            booking_id = next(self.ids)
            self.bookings[booking_id] = {"room": room, "start": start, "end": end, "checked_in": False}
            return {"id": booking_id}
        if action in {"cancel", "check-in", "status"}:
            booking_id = event["id"]
            if type(booking_id) is not int or booking_id not in self.bookings:
                raise ValueError("unknown booking")
            booking = self.bookings[booking_id]
            if action == "cancel":
                del self.bookings[booking_id]
                return {"cancelled": booking_id}
            if action == "check-in":
                now = timestamp(event["at"])
                if not booking["start"] <= now < booking["end"]:
                    raise ValueError("check-in outside booking interval")
                booking["checked_in"] = True
            return {"id": booking_id, "checked_in": booking["checked_in"]}
        raise ValueError("unknown action")


def run(lines):
    studio = Studio()
    for line in lines:
        try:
            event = json.loads(line)
            if not isinstance(event, dict):
                raise ValueError("expected a JSON object")
            result = studio.apply(event)
        except (ValueError, KeyError, TypeError, OverflowError) as error:
            result = {"error": str(error)}
        print(json.dumps(result))


if __name__ == "__main__":
    run(sys.stdin)
