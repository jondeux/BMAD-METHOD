from datetime import datetime, timezone
from itertools import count
from threading import Lock

from flask import Flask, jsonify, request

ROOMS = ("Maple", "Cedar", "Birch")


def parse_timestamp(value):
    if not isinstance(value, str) or "T" not in value:
        raise ValueError("use ISO 8601 timestamps with UTC offsets")
    parsed = datetime.fromisoformat(value)
    if parsed.utcoffset() is None:
        raise ValueError("use ISO 8601 timestamps with UTC offsets")
    return parsed.astimezone(timezone.utc)


def create_app(clock=lambda: datetime.now(timezone.utc)):
    app = Flask(__name__)
    bookings = {}
    ids = count(1)
    lock = Lock()

    @app.get("/rooms")
    def rooms():
        return jsonify(list(ROOMS))

    @app.post("/bookings")
    def book():
        data = request.get_json(silent=True)
        if not isinstance(data, dict) or data.get("room") not in ROOMS:
            return jsonify(error="provide a known room and start/end times"), 400
        try:
            start = parse_timestamp(data.get("start"))
            end = parse_timestamp(data.get("end"))
        except (ValueError, OverflowError):
            return jsonify(error="use ISO 8601 timestamps with UTC offsets"), 400
        if start >= end:
            return jsonify(error="end must follow start"), 400

        with lock:
            if any(row["room"] == data["room"] and begins < end and start < ends
                   for row, begins, ends in bookings.values()):
                return jsonify(error="booking overlaps"), 409
            booking_id = next(ids)
            row = {"id": booking_id, "room": data["room"],
                   "start": data["start"], "end": data["end"], "checked_in": False}
            bookings[booking_id] = (row, start, end)
            return jsonify(row), 201

    @app.get("/bookings/<int:booking_id>")
    def get_booking(booking_id):
        with lock:
            entry = bookings.get(booking_id)
            if entry is None:
                return jsonify(error="unknown booking"), 404
            return jsonify(entry[0])

    @app.post("/bookings/<int:booking_id>/check-in")
    def check_in(booking_id):
        with lock:
            entry = bookings.get(booking_id)
            if entry is None:
                return jsonify(error="unknown booking"), 404
            row, start, end = entry
            if not start <= clock() < end:
                return jsonify(error="check-in outside booking interval"), 409
            row["checked_in"] = True
            return jsonify(row)

    return app


app = create_app()
