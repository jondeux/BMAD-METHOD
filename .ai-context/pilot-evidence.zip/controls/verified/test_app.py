import unittest
from concurrent.futures import ThreadPoolExecutor
from datetime import datetime
from threading import Barrier

from app import create_app


class BookingApi(unittest.TestCase):
    def setUp(self):
        self.now = datetime.fromisoformat("2026-11-24T10:00:00Z")
        self.app = create_app(lambda: self.now)
        self.client = self.app.test_client()

    def book(self, start="2026-11-24T10:00Z", end="2026-11-24T11:00Z", room="Maple"):
        return self.client.post("/bookings", json={"room": room, "start": start, "end": end})

    def test_legacy_routes_and_adjacent_intervals(self):
        self.assertEqual(self.client.get("/rooms").get_json(), ["Maple", "Cedar", "Birch"])
        self.assertEqual(self.book().status_code, 201)
        self.assertEqual(self.book("2026-11-24T06:00-05:00", "2026-11-24T07:00-05:00").status_code, 201)
        self.assertEqual(self.book("2026-11-24T10:30Z", "2026-11-24T11:30Z").status_code, 409)
        self.assertEqual(self.book(room="Cedar").status_code, 201)

    def test_input_errors(self):
        for start, end in [("2026-11-24T10:00", "2026-11-24T11:00Z"),
                           ("2026-11-24T10:00Z", "2026-11-24T11:00+02:00"),
                           ("bad", "2026-11-24T11:00Z"),
                           ("2026-11-24T10:00Z", "2026-11-24T10:00Z")]:
            with self.subTest(start=start, end=end):
                self.assertEqual(self.book(start, end).status_code, 400)
        self.assertEqual(self.client.post("/bookings", json=[]).status_code, 400)
        self.assertEqual(self.client.post("/bookings/1/check-in").status_code, 404)

    def test_boundary_and_no_mutation(self):
        first = self.book().get_json()
        later = self.book("2026-11-24T11:00Z", "2026-11-24T12:00Z").get_json()
        self.now = datetime.fromisoformat("2026-11-24T09:59:59Z")
        self.assertEqual(self.client.post("/bookings/1/check-in").status_code, 409)
        self.now = datetime.fromisoformat("2026-11-24T11:00:00Z")
        self.assertEqual(self.client.post("/bookings/1/check-in").status_code, 409)
        self.assertEqual(self.client.get("/bookings/1").get_json(), first)
        self.assertEqual(self.client.get("/bookings/2").get_json(), later)
        accepted = self.client.post("/bookings/2/check-in")
        self.assertEqual(accepted.status_code, 200)
        self.assertTrue(accepted.get_json()["checked_in"])

    def test_concurrent_overlap_has_one_winner(self):
        barrier = Barrier(2, timeout=5)

        def place():
            with self.app.test_client() as client:
                barrier.wait()
                return client.post("/bookings", json={"room": "Maple", "start": "2026-11-24T10:00Z",
                                                     "end": "2026-11-24T11:00Z"}).status_code

        with ThreadPoolExecutor(max_workers=2) as executor:
            results = sorted(executor.map(lambda _: place(), range(2)))
        self.assertEqual(results, [201, 409])

    def test_repeated_active_check_in_keeps_same_booking(self):
        booking = self.book().get_json()
        path = f"/bookings/{booking['id']}"
        expected = {**booking, "checked_in": True}

        first = self.client.post(f"{path}/check-in")
        second = self.client.post(f"{path}/check-in")
        current = self.client.get(path)

        self.assertEqual(first.status_code, 200)
        self.assertEqual(second.status_code, 200)
        self.assertEqual(current.status_code, 200)
        self.assertEqual(first.get_json(), expected)
        self.assertEqual(second.get_json(), expected)
        self.assertEqual(current.get_json(), expected)

    def test_booking_rejects_non_iso_datetime_separator(self):
        cases = (
            ("2026-11-24X10:00Z", "2026-11-24T11:00Z"),
            ("2026-11-24T12:00Z", "2026-11-24X13:00Z"),
        )
        for start, end in cases:
            with self.subTest(start=start, end=end):
                response = self.book(start, end)
                self.assertEqual(response.status_code, 400)
                self.assertEqual(response.get_json(), {"error": "use ISO 8601 timestamps with UTC offsets"})
