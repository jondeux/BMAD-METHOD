---
title: 'Workshop capacity query'
type: feature
ticket: ''
created: '2026-11-25'
status: built
baseline_revision: NO_VCS
route: oneshot
route_source: pinned
risk: low
review: quick
review_source: pinned
lenses_ran: [quick]
review_loop_iteration: 0
followup_review_recommended: false
context: []
warnings: []
deferred: []
---

<intent-contract>

## Intent

**Problem.** The synthetic workshop pilot needs a read-only remaining-seat count.

**Approach.** Implement capacity.sql as one SQLite SELECT using :session_id and :capacity. The aggregate counts confirmed bookings for the requested session only, defaults to zero booked seats, and floors the remainder at zero. Execute the original fixture cases A at capacities 10 and 4 plus an empty session at capacity 10. Product Brief owns the three document checks.

</intent-contract>

## Implementation Notes

An isolated single-query change with an executable in-memory fixture.

Added a read-only aggregate with named parameters. COALESCE handles an absent session. The outer two-argument MAX floors the result.

## Plan Change Log

## Review Triage Log

### 2026-11-25 — Quick review
- Verdicts — 0 findings. High 0, medium 0, low 0, false 0, maybe-false 0.
- Findings — none.

## Verification

Run `python3 -B check_build.py` and require every original code example to pass.


## Auto Run Result

Status: built

- Added [capacity.sql](../capacity.sql) and a local executable acceptance fixture.
- The [quick review](quick-review.md) reported zero findings. Patched counts were high 0, medium 0, low 0. No findings were deferred or rejected.
- Follow-up review recommended: false.
- `python3 -B check_build.py` passed. Three SQLite examples passed with read-only enforcement and an integer result check. [Execution log](verification.txt)
- The result covers the supplied synthetic inputs and constraints.
