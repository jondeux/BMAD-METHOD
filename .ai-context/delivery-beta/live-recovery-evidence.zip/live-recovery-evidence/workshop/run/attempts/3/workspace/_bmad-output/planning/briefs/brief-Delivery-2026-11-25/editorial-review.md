# Workshop pilot brief review

| Pass | Finding | Applied change |
| --- | --- | --- |
| Structure | The continuation decision appeared twice. | Moved the end-of-week decision into the opening proposal and kept the evidence section focused on the fixture. |
| Structure | Staff logging, query behavior, and fixture exclusions define the pilot. | Preserved those details. |
| Prose | Staff need to know which value to compare. | Named the reported seat count and the bookings record. |
| Prose | The capacity sentence could be clearer about which bookings count. | Tied the threshold to confirmed bookings for the selected session. |
| Prose | Fixture coverage could be easier to scan. | Named the covered booking cases and stated the waitlist exclusion directly. |
| Prose | The decision sequence can be stated more directly. | Specified that the coordinator reviews discrepancies before deciding whether to continue. |
