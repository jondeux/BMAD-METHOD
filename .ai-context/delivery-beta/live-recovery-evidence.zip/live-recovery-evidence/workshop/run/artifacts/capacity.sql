SELECT MAX(0, :capacity - COALESCE(SUM(seats), 0)) AS remaining_seats
FROM bookings
WHERE session_id = :session_id
  AND status = 'confirmed';
