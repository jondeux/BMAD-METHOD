---
title: 'Workshop capacity pilot'
status: complete
created: '2026-11-25'
updated: '2026-11-25'
---

# Workshop capacity pilot

## Proposed decision

Run a one-week internal pilot of the remaining-seat query. The workshop coordinator is the proposed pilot owner. At the end of the week, the coordinator would review logged discrepancies before deciding whether to continue.

## Pilot scope

The query counts confirmed bookings for the selected session and reports zero remaining seats when those bookings reach capacity. During the pilot, staff can check the reported seat count against the bookings record and log any discrepancies.

## Fixture coverage

The test data included confirmed and canceled bookings, bookings for another session, and a session with no bookings. The test exercised the zero-seat floor. The fixture excludes waitlist behavior.
