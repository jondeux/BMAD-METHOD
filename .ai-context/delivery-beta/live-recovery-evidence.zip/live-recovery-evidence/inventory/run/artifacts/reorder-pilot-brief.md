---
title: 'Inventory reorder pilot'
status: complete
created: '2026-11-25'
updated: '2026-11-25'
---

# Inventory reorder pilot

## Proposed decision

Run a one-week pilot. Staff manually review reorder suggestions before placing orders and record which suggestions they would override. The inventory lead is the proposed decision owner. At the end of the week, the lead reviews the pilot results and uses staff observations to decide whether to continue.

## Reorder rule

The rule calculates available stock by subtracting reservations from stock on hand and treating any negative result as zero. It suggests a reorder when available stock is below the reorder point.

## Fixture coverage

The fixture covers four cases. Available stock is below the reorder point, available stock equals the reorder point, reservations exceed stock on hand, or the reorder point is zero. The fixture excludes supplier lead times.
