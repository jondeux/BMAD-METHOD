def should_reorder(on_hand: int, reserved: int, reorder_point: int) -> bool:
    """Return whether unreserved stock falls below the reorder point."""
    available = max(0, on_hand - reserved)
    return available < reorder_point
