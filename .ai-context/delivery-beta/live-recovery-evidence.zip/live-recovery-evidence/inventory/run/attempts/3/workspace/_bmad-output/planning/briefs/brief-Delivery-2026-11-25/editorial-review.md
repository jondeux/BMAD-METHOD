# Inventory pilot brief review

| Pass | Finding | Applied change |
| --- | --- | --- |
| Structure | Staff responsibilities and the continuation decision were scattered across sections. | Grouped both in the proposed decision. |
| Structure | Headings could more directly identify what each section contains. | Named the sections Reorder rule and Fixture coverage. |
| Structure | The four fixture cases and lead-time exclusion define the evidence. | Preserved all five details. |
| Prose | Available stock could be defined before describing the comparison. | Defined it first and described when the rule suggests an order. |
| Prose | The fixture used terms that differed from the rule description. | Used reorder point throughout and named the four cases. |
| Prose | The pilot duration, staff tasks, and owner decision competed within sentences. | Used short sentences to state the duration, manual review, proposed owner, and decision evidence. |
