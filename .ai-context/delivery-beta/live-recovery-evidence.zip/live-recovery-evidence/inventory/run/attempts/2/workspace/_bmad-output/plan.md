---
title: 'Inventory reorder rule'
type: feature
ticket: ''
created: '2026-11-25'
status: built
baseline_revision: NO_VCS
route: oneshot
route_source: pinned
risk: low
review: quick
review_source: pinned
lenses_ran: [quick]
review_loop_iteration: 0
followup_review_recommended: false
context: []
warnings: []
deferred: []
---

<intent-contract>

## Intent

**Problem.** The synthetic one-week pilot needs a rule staff can evaluate consistently.

**Approach.** Implement should_reorder(on_hand, reserved, reorder_point) in reorder.py using only standard Python. For nonnegative integer inputs, clamp available stock to zero and compare it strictly below the threshold. Execute all four original examples, checking exact boolean results. Product Brief owns the three document checks.

</intent-contract>

## Implementation Notes

An isolated pure function with four direct executable checks.

Added the pure three-argument Python function. A strict comparison preserves the specified equality and zero-threshold behavior.

## Plan Change Log

## Review Triage Log

### 2026-11-25 — Quick review
- Verdicts — 0 findings. High 0, medium 0, low 0, false 0, maybe-false 0.
- Findings — none.

## Verification

Run `python3 -B check_build.py` and require every original code example to pass.


## Auto Run Result

Status: built

- Added [reorder.py](../reorder.py) and a local executable acceptance fixture.
- The [quick review](quick-review.md) reported zero findings. Patched counts were high 0, medium 0, low 0. No findings were deferred or rejected.
- Follow-up review recommended: false.
- `python3 -B check_build.py` passed. Four executable examples returned their expected boolean results. [Execution log](verification.txt)
- The result covers the supplied synthetic inputs and constraints.
