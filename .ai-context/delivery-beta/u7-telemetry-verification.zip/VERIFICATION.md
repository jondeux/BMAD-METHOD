# v0.3.0 U7 and telemetry verification

Date 2026-11-26

- Full Python suite `uv run --frozen python -B -m pytest -n 3 -q` passed with one optional tiktoken skip.
- Python docs reference tests passed all three cases. The checker scanned 52 documents with zero findings.
- The docs-site link validator passed all 49 documents. Node 24.22.3 built the site, ran the full docs-site tests, and validated sidebar order.
- Strict skill validation passed all 33 skills. Ruff lint, format, and git diff --check passed for the updated sources.
- The v0.3.0 ZIP rebuilt byte for byte after the freshness sweep. The installed compatibility checker covered 46 files.
- The packaged controller ran a three-dispatch offline delivery. The automatic sidecar matched the explicit export and contained none of the planted task, path, or raw-log strings.
- The older Lantern House run exported six dispatches with two checker faults and four passing checks. The report contains only operational fields.
- All 50 hosted files matched the update and retained icon. Host discovery confirmed the installed local version is v0.3.0 and enabled. The v0.2.0 cache still passed its own checker.
