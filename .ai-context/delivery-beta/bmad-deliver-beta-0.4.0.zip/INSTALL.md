# Install the local BMad delivery beta

Use Python 3.11 or later on a POSIX host. Native delivery needs `uv` for workflow
dependencies and an authorized workspace agent with access to the project, native
workflow tools, and review subagents. Start native runs from that agent so it can
serve each build job. The standard `--codex` intake launcher uses the `codex`
executable on `PATH` and a signed-in subscription. Signed-in routing was tested
with Codex. Claude Code workspace intake is a preview with deterministic checks
only. Native preparation writes the requested
communication and document languages to the job configuration. Both default
to English.

| Request | Native route |
| --- | --- |
| Code | Build Auto |
| Document | Product Brief |
| Code and document | Build Auto, then Product Brief |

The beta delivers run-local UTF-8 text files. The 4 MiB limit applies to each complete
serialized JSON receipt, including all files and metadata in that receipt. If a
native submission exceeds the limit, reduce the artifact text or omit optional
outputs and resubmit the same job. When `--codex` verifies mixed delivery, its job
must fit both builds' artifacts, the
request, and metadata within 8 MiB. Requests for a binary file or a different
native workflow need a separately agreed route or deliverable before dispatch.

## Install the skill

Verify the ZIP against its separately published SHA-256 digest before extracting
it to a new directory. Use `sha256sum -c SHA256SUMS` in the extracted standalone
archive to verify its contents, or `shasum -a 256 -c SHA256SUMS` if your host has
`shasum`. Run the read-only compatibility checker from the extracted copy. Add
`--native` to check for `uv` and `--codex` to check for the standard launcher.

```bash
python3 -B bmad-deliver/scripts/check_install.py --native --codex
```

Open a terminal in the project that should use the skill, and copy it into that project.

```bash
test ! -L .agents &&
test ! -L .agents/skills &&
mkdir -p .agents/skills &&
mkdir .agents/skills/bmad-deliver &&
cp -R /absolute/path/to/extracted/bmad-deliver/. .agents/skills/bmad-deliver/
```

Run the compatibility checker against the installed copy before opening its first
workspace agent session. Invoke `$bmad-deliver` with the
intended deliverable and observable checks. For Mode A, approve the proposal before
the build. For Mode B, state the delegated outcome and limits. Mode C preserves the
named deliverable.

## Update or roll back

Extract and verify the candidate in a new directory. Use each release's own
checker. To verify a copied install, pass its skill directory as the first argument
to the matching checker.

```bash
python3 -B /path/to/candidate/bmad-deliver/scripts/check_install.py /path/to/candidate-project/.agents/skills/bmad-deliver --native --codex
```

Install the candidate in a separate project or worktree with its own
`.agents/skills` directory. Start a fresh workspace session there for new runs.
Keep existing runs with the installation that started them because saved
worker paths are absolute. To roll back new work, reopen the previous project
and use its saved runtime. Keep the candidate available for runs with raw intake.
From the previous project, verify the original v0.3.0 portable ZIP against its
separately published digest. Extract it into an empty directory and use its
checker to verify the installed skill before opening the saved run.

```bash
archive_dir=/path/to/original/archives
original=$(mktemp -d) &&
(cd "$archive_dir" &&
  sed -n '/  autonomous-delivery-beta-0\.3\.0\.zip$/p' autonomous-delivery-beta-0.3.0.zip.sha256 | sha256sum -c -) &&
python3 -m zipfile -e "$archive_dir/autonomous-delivery-beta-0.3.0.zip" "$original" &&
python3 -B "$original/skills/bmad-deliver/scripts/check_install.py" .agents/skills/bmad-deliver &&
python3 -B .agents/skills/bmad-deliver/scripts/deliver.py status /path/to/saved-run
```

Use `shasum -a 256 -c -` in place of `sha256sum -c -` where needed.

## Rebuild a bundle

From the source checkout, use the allowed working-tree files and the pinned
Product Brief commit. The ZIP records the builder hash, input source paths, and
input hashes in `bmad-deliver/assets/native/SOURCE.json`. Use the same builder and
matching source paths from the project. The archived members supply the original
input bytes, and the manifest distinguishes the working tree from the pinned
history. Pass the manifest from the extracted original when rebuilding.

```bash
python3 -B tools/package_delivery_beta.py /tmp/original-beta.zip
python3 -m zipfile -e /tmp/original-beta.zip /tmp/original-beta
python3 -B tools/package_delivery_beta.py /tmp/rebuilt-beta.zip --inputs /tmp/original-beta/bmad-deliver/assets/native/SOURCE.json
cmp /tmp/original-beta.zip /tmp/rebuilt-beta.zip
```

Use `--plugin` to build the portable plugin layout. It uses the manifest and icon
from the checksum-pinned v0.3.0 archive. The portable build carries the same skill
payload and `SOURCE.json` under `skills/`.

```bash
python3 -B tools/package_delivery_beta.py /tmp/original-plugin.zip --plugin
python3 -m zipfile -e /tmp/original-plugin.zip /tmp/original-plugin
python3 -B tools/package_delivery_beta.py /tmp/rebuilt-plugin.zip --plugin --inputs /tmp/original-plugin/skills/bmad-deliver/assets/native/SOURCE.json
cmp /tmp/original-plugin.zip /tmp/rebuilt-plugin.zip
```

## Try an example

**Supported document.** Expect Product Brief to produce a local Markdown brief.

```text
$bmad-deliver Mode C. Write decision-brief.md for an internal booking trial.
State that the simulation omitted false releases and name the facilities director
as the proposed decision owner. Verify both statements. Keep the brief local.
```

**Supported code.** Expect Build Auto to produce a local Python file. Configure a
[trusted local checker](bmad-deliver/references/run-record.md#acceptance-checks) that
can execute the Python checks before starting.

```text
$bmad-deliver Mode C. Write a local capacity.py that defines remaining(capacity, booked)
for nonnegative integers. Return the remaining seats, floored at zero. Verify that
remaining(10, 6) returns 4 and remaining(4, 6) returns 0.
```

**Outside native scope.** The requested file needs a binary-capable workflow. Choose
a separate workflow for the slide deck or agree to a Markdown outline before starting
a delivery run.

```text
$bmad-deliver Mode C. Deliver a finished slide deck as a .pptx file.
```

To resume, give the same skill the saved run path. See the
[run and receipt contract](bmad-deliver/references/run-record.md) and
[workspace host instructions](bmad-deliver/references/native-host.md).

Each run saves a local `telemetry.json` with shareable diagnostics. From the
extracted bundle, export a fresh copy after a crash or for an older run.

```bash
python3 -B bmad-deliver/scripts/deliver.py telemetry /path/to/run > delivery-telemetry.json
```

See the [U7 evaluation guide](bmad-deliver/references/evaluate-delivery.md) for
checker preflight and the bundled evaluation cases.
